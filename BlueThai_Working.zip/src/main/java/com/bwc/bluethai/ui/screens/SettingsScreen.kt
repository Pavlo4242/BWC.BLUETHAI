
package com.bwc.bluethai.ui.screens
/** LOgs not capturing what we need -- API Key Selector still wrong, still getting asterisks on the screen */
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.bwc.bluethai.viewmodel.ModelSelectionState
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    availableKeys: Map<String, String>,
    currentKeyName: String,
    onApiKeySelected: (String) -> Unit,
    currentFontSize: Int,
    onFontSizeChange: (Int) -> Unit,
    useCustomPrompt: Boolean,
    onUseCustomPromptChange: (Boolean) -> Unit,
    modelSelection: ModelSelectionState,
    onModelSelectionChange: (ModelSelectionState) -> Unit,
    onNavigateToDebugLogs: () -> Unit,
    onNavigateToHistory: () -> Unit,
    onNavigateBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .padding(paddingValues)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            // API Key Slider
            item {
                Column {
                    val keyNames = availableKeys.keys.toList()
                    val currentIndex = keyNames.indexOf(currentKeyName)
                    Text("API Key: $currentKeyName", style = MaterialTheme.typography.titleMedium)
                    Slider(
                        value = currentIndex.toFloat(),
                        onValueChange = { onApiKeySelected(keyNames[it.roundToInt()]) },
                        valueRange = 0f..(keyNames.size - 1).toFloat(),
                        steps = keyNames.size - 2
                    )
                }
            }

            // Model Selector
            item {
                Column {
                    Text("Model: ${modelSelection.getModelName()}", style = MaterialTheme.typography.titleMedium)
                    // Version Slider
                    val versionIndex = when(modelSelection.version) {
                        1.5f -> 0
                        2.0f -> 1
                        else -> 2 // 2.5f
                    }
                    Slider(
                        value = versionIndex.toFloat(),
                        onValueChange = {
                            val newVersion = when(it.roundToInt()) {
                                0 -> 1.5f
                                1 -> 2.0f
                                else -> 2.5f
                            }
                            onModelSelectionChange(modelSelection.copy(version = newVersion))
                        },
                        valueRange = 0f..2f,
                        steps = 1
                    )
                    // Pro/Flash Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text("Flash")
                        Switch(
                            checked = modelSelection.isPro,
                            onCheckedChange = { onModelSelectionChange(modelSelection.copy(isPro = it)) },
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                        Text("Pro")
                    }
                }
            }

            // Font Size Slider
            item {
                Column {
                    Text("Font Size: ${currentFontSize}sp", style = MaterialTheme.typography.titleMedium)
                    Slider(
                        value = currentFontSize.toFloat(),
                        onValueChange = { onFontSizeChange(it.roundToInt()) },
                        valueRange = 14f..28f,
                        steps = 6
                    )
                }
            }

            // Custom Prompt Toggle
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Use Debug Prompt")
                        Text("Translates like a pirate", style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(
                        checked = useCustomPrompt,
                        onCheckedChange = onUseCustomPromptChange
                    )
                }
            }

            // Navigation Links
            item {
                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
            }
            item {
                SettingsNavigationItem(
                    icon = Icons.Default.History,
                    text = "Conversation History",
                    onClick = onNavigateToHistory
                )
            }
            item {
                SettingsNavigationItem(
                    icon = Icons.Default.BugReport,
                    text = "View Raw Debug Logs",
                    onClick = onNavigateToDebugLogs
                )
            }
        }
    }
}

@Composable
private fun SettingsNavigationItem(
    icon: ImageVector,
    text: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.padding(end = 16.dp))
        Text(text)
    }
}