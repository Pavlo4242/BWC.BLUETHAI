package com.bwc.bluethai.ui.screens

import android.Manifest
import android.widget.Toast
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.viewmodel.compose.viewModel
import com.bwc.bluethai.data.model.ChatState
import com.bwc.bluethai.data.model.ConversationSession
import com.bwc.bluethai.data.model.SessionPreview
import com.bwc.bluethai.data.model.TranslationEntry
import com.bwc.bluethai.ui.components.ControlsBar
import com.bwc.bluethai.ui.components.HistoryDialog
import com.bwc.bluethai.ui.components.chat.ChatList
import com.bwc.bluethai.ui.components.chat.InitialPlaceholder
import com.bwc.bluethai.ui.theme.BWCTranslatorTheme
import com.bwc.bluethai.viewmodel.InputMode
import com.bwc.bluethai.viewmodel.TranslatorUiState
import com.bwc.bluethai.viewmodel.TranslatorViewModel
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import java.util.Date

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun TranslatorScreen(
    viewModel: TranslatorViewModel = viewModel(),
    onNavigateToHistory: () -> Unit // Add this
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    val recordAudioPermission = rememberPermissionState(Manifest.permission.RECORD_AUDIO)

    val successState = uiState as? TranslatorUiState.Success
    LaunchedEffect(successState?.error) {
        successState?.error?.let {
            Toast.makeText(context, it, Toast.LENGTH_LONG).show()
            viewModel.clearError()
        }
    }

    val showHistoryDialog by viewModel.showHistoryDialog.collectAsState()

    TranslatorScreenContent(
        uiState = uiState,
        isMicEnabled = recordAudioPermission.status.isGranted,
        isPlaybackEnabled = successState?.isPlaybackEnabled ?: false,
        showHistoryDialog = showHistoryDialog,
        onMicPress = {
            if (recordAudioPermission.status.isGranted) {
                viewModel.startListening()
            } else {
                recordAudioPermission.launchPermissionRequest()
            }
        },
        onMicRelease = { viewModel.stopListening() },
        onMicClick = {
            if (recordAudioPermission.status.isGranted) {
                viewModel.toggleListening()
            } else {
                recordAudioPermission.launchPermissionRequest()
            }
        },
        onPlaybackChange = { viewModel.setPlaybackEnabled(it) },
        onSwapLanguage = { viewModel.swapLanguage() },
        onModeChange = { viewModel.setInputMode(it) },
        onHistoryClick = onNavigateToHistory, // Use onNavigateToHistory
        onDismissHistory = { viewModel.toggleHistoryDialog(false) },
        onSessionClick = { viewModel.loadSession(it) },
        onDeleteSession = { viewModel.deleteSession(it) },
        onNewChatClick = { viewModel.startNewSession() },
        onSpeakEnglish = { text -> viewModel.speak(text, isEnglish = true) },
        onSpeakThai = { text -> viewModel.speak(text, isEnglish = false) }
    )
}

@Composable
fun TranslatorScreenContent(
    uiState: TranslatorUiState,
    isMicEnabled: Boolean,
    showHistoryDialog: Boolean,
    isPlaybackEnabled: Boolean = false,
    onPlaybackChange: (Boolean) -> Unit,
    onMicPress: () -> Unit,
    onMicRelease: () -> Unit,
    onMicClick: () -> Unit,
    onSwapLanguage: () -> Unit,
    onModeChange: (InputMode) -> Unit,
    onHistoryClick: () -> Unit,
    onDismissHistory: () -> Unit,
    onSessionClick: (Long) -> Unit,
    onDeleteSession: (Long) -> Unit,
    onNewChatClick: () -> Unit,
    onSpeakEnglish: (String) -> Unit,
    onSpeakThai: (String) -> Unit
) {
    val successState = uiState as? TranslatorUiState.Success

    if (showHistoryDialog) {
        HistoryDialog(
            sessions = successState?.sessions ?: emptyList(),
            onDismiss = onDismissHistory,
            onSessionClick = onSessionClick,
            onDeleteClick = onDeleteSession,
            onNewChatClick = onNewChatClick
        )
    }

    Scaffold(
        bottomBar = {
            if (successState != null) {
                ControlsBar(
                    isListening = successState.isListening,
                    isInputEnglish = successState.isInputEnglish,
                    inputMode = successState.inputMode,
                    isMicEnabled = isMicEnabled,
                    isPlaybackEnabled = successState.isPlaybackEnabled,
                    onMicPress = onMicPress,
                    onMicRelease = onMicRelease,
                    onMicClick = onMicClick,
                    onSwapLanguage = onSwapLanguage,
                    onModeChange = onModeChange,
                    onSettingsClick = onHistoryClick,
                    onPlaybackChange = onPlaybackChange
                )
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (val state = uiState) {
                is TranslatorUiState.Loading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        InitialPlaceholder(text = "Loading session...")
                    }
                }
                is TranslatorUiState.Success -> {
                    if (state.currentEntries.isEmpty() && state.interimText.isEmpty() && state.streamingTranslation == null) {
                        InitialPlaceholder(text = "Tap or hold the mic to start.")
                    } else {
                        val chatState = ChatState(
                            entries = state.currentEntries.map { entry ->
                                ChatState.Entry(
                                    id = entry.id,
                                    englishText = entry.englishText,
                                    thaiText = entry.thaiText,
                                    isFromEnglish = entry.isFromEnglish
                                )
                            },
                            interimText = state.interimText,
                            isInputEnglish = state.isInputEnglish,
                            streamingTranslation = state.streamingTranslation
                        )
                        ChatList(
                            state = chatState,
                            onSpeakEnglish = onSpeakEnglish,
                            onSpeakThai = onSpeakThai
                        )
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true, name = "Screen - Empty State")
@Composable
fun TranslatorScreenPreview_Empty() {
    val emptyState = TranslatorUiState.Success(
        currentEntries = emptyList(),
        sessions = listOf(
            SessionPreview(
                session = ConversationSession(1L, Date()),
                previewText = "Previous chat..."
            )
        )
    )
    BWCTranslatorTheme {
        TranslatorScreenContent(
            uiState = emptyState,
            isMicEnabled = true,
            isPlaybackEnabled = true,
            showHistoryDialog = false,
            onMicPress = {},
            onMicRelease = {},
            onMicClick = {},
            onSwapLanguage = {},
            onModeChange = {},
            onHistoryClick = {}, // Updated
            onDismissHistory = {},
            onSessionClick = {},
            onDeleteSession = {},
            onNewChatClick = {},
            onSpeakEnglish = {},
            onSpeakThai = {},
            onPlaybackChange = {}
        )
    }
}