package com.bwc.bluethai.viewmodel

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.bwc.bluethai.BuildConfig
import com.bwc.bluethai.data.model.SessionPreview
import com.bwc.bluethai.data.model.TranslationEntry
import com.bwc.bluethai.data.repository.TranslationRepository
import com.bwc.bluethai.services.RecognitionState
import com.bwc.bluethai.services.SpeechRecognizerService
import com.bwc.bluethai.services.TextToSpeechService
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

val availableApiKeys = mapOf(
    "Key 1" to BuildConfig.GEMINI_API_KEY,
    "Key 2" to BuildConfig.GEMINI_API_KEY_DEBUG_1,
    "Key 3" to BuildConfig.GEMINI_API_KEY_DEBUG_2,
    "Key 4" to BuildConfig.GEMINI_API_KEY_DEBUG_3
)

data class ModelSelectionState(
    val version: Float = 1.5f,
    val isPro: Boolean = false
) {
    fun getModelName(): String {
        val type = if (isPro) "pro" else "flash"
        return "gemini-$version-$type"
    }
}

enum class InputMode { HOLD, TAP }

sealed class TranslatorUiState {
    data object Loading : TranslatorUiState()
    data class Success(
        val baseFontSize: Int = 18,
        val currentApiKeyName: String = "Key 1",
        val currentEntries: List<TranslationEntry> = emptyList(),
        val currentSessionId: Long? = null,
        val debugLogs: List<String> = emptyList(),
        val error: String? = null,
        val inputMode: InputMode = InputMode.HOLD,
        val interimText: String = "",
        val isInputEnglish: Boolean = true,
        val isListening: Boolean = false,
        val isPlaybackEnabled: Boolean = true,
        val modelSelection: ModelSelectionState = ModelSelectionState(),
        val sessions: List<SessionPreview> = emptyList(),
        val streamingTranslation: Pair<String, String>? = null,
        val useCustomPrompt: Boolean = false,
    ) : TranslatorUiState()
}



@OptIn(ExperimentalCoroutinesApi::class)
class TranslatorViewModel(application: Application) : ViewModel() {

    private val repository = TranslationRepository(application)
    private val speechRecognizer = SpeechRecognizerService(application)
    private val textToSpeech = TextToSpeechService(application) { isSuccess ->
        // Can handle TTS init status if needed
    }

    // Use TranslatorUiState.Success directly as the internal state holder.
    private val _internalState = MutableStateFlow(TranslatorUiState.Success())
    private val _currentSessionId = MutableStateFlow<Long?>(null)
    private var translationJob: Job? = null

    // This flow reactively provides the entries for the currently selected session
    private val entriesForCurrentSession: StateFlow<List<TranslationEntry>> = _currentSessionId
        .filterNotNull()
        .flatMapLatest { sessionId ->
            repository.getEntriesForSession(sessionId)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // This flow reactively provides all sessions with their text previews for the history dialog
    private val sessionsWithPreviews: StateFlow<List<SessionPreview>> =
        repository.getSessionsWithPreviews()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // The final UI state is a combination of all our reactive streams
    val uiState: StateFlow<TranslatorUiState> = combine(
        _internalState,
        _currentSessionId,
        entriesForCurrentSession,
        sessionsWithPreviews
    ) { internalState, sessionId, entries, sessions ->
        // The internal state holds the base UI settings, combine enriches it with data from other flows.
        internalState.copy(
            currentSessionId = sessionId,
            currentEntries = entries,
            sessions = sessions
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = TranslatorUiState.Loading
    )

    private val _showHistoryDialog = MutableStateFlow(false)
    val showHistoryDialog: StateFlow<Boolean> = _showHistoryDialog.asStateFlow()

    // The private SuccessState data class is now removed.

    init {
        // Handle speech recognition states
        viewModelScope.launch {
            speechRecognizer.recognitionState.collect { state ->
                handleRecognitionState(state)
            }
        }
        // Determine the initial session to load
        viewModelScope.launch {
            val sessions = repository.getAllSessions().first()
            if(sessions.isEmpty()) {
                startNewSession()
            } else {
                loadSession(sessions.first().id)
            }
        }
    }

    private fun handleRecognitionState(state: RecognitionState) {
        _internalState.update {
            when (state) {
                is RecognitionState.Listening -> it.copy(isListening = true, interimText = "")
                is RecognitionState.Idle -> it.copy(isListening = false)
                is RecognitionState.PartialResult -> it.copy(interimText = state.text)
                is RecognitionState.FinalResult -> {
                    if (state.text.isNotBlank()) {
                        processFinalTranscript(state.text)
                    }
                    it.copy(isListening = false, interimText = "")
                }
                is RecognitionState.Error -> it.copy(error = state.message, isListening = false)
            }
        }
    }

    private fun processFinalTranscript(text: String) {
        translationJob?.cancel()
        translationJob = viewModelScope.launch {
            val currentState = _internalState.value
            val sourceText = text
            var translatedText = ""

            _internalState.update { it.copy(streamingTranslation = sourceText to "") }

            try {

                // Perform the translation
                repository.translateText(text).collect { streamedText ->
                    translatedText = streamedText
                    _internalState.update { it.copy(streamingTranslation = sourceText to translatedText) }
                }

                // Save the completed entry
                val sessionId = _currentSessionId.value ?: return@launch
                val newEntry = TranslationEntry(
                    sessionId = sessionId,
                    englishText = if (currentState.isInputEnglish) sourceText else translatedText,
                    thaiText = if (currentState.isInputEnglish) translatedText else sourceText,
                    isFromEnglish = currentState.isInputEnglish
                )
                repository.saveTranslationEntry(newEntry)

                // Speak the result if enabled
                if (currentState.isPlaybackEnabled) {
                    speak(translatedText, !currentState.isInputEnglish)
                }

            } catch (e: Exception) {
                _internalState.update { it.copy(error = "Translation failed: ${e.message}") }
            } finally {
                // Always clear the streaming state, whether it succeeded or failed
                _internalState.update { it.copy(streamingTranslation = null) }
            }
        }
    }

    // --- Public actions from UI ---

    // --- State Management ---

    fun setInputMode(mode: InputMode) = _internalState.update { it.copy(inputMode = mode) }

    fun swapLanguage() = _internalState.update { it.copy(isInputEnglish = !it.isInputEnglish) }

    fun clearError() = _internalState.update { it.copy(error = null) }

    fun setFontSize(size: Int) = _internalState.update { it.copy(baseFontSize = size) }

    fun setPlaybackEnabled(isEnabled: Boolean) = _internalState.update { it.copy(isPlaybackEnabled = isEnabled) }

    fun setApiKey(keyName: String) = _internalState.update { it.copy(currentApiKeyName = keyName) }

    fun setUseCustomPrompt(useCustom: Boolean) = _internalState.update { it.copy(useCustomPrompt = useCustom) }

    fun updateModelSelection(newSelection: ModelSelectionState) = _internalState.update { it.copy(modelSelection = newSelection) }


    // --- Speech Handling ---

    fun startListening() = speechRecognizer.startListening(_internalState.value.isInputEnglish)

    fun stopListening() = speechRecognizer.stopListening()

    fun toggleListening() {
        if (_internalState.value.isListening) stopListening() else startListening()
    }

    fun speak(text: String, isEnglish: Boolean) {
        if (_internalState.value.isPlaybackEnabled) {
            textToSpeech.speak(text, isEnglish)
        }
    }

    // --- Session Management ---

    fun toggleHistoryDialog(show: Boolean) {
        _showHistoryDialog.value = show
    }

    fun loadSession(sessionId: Long) {
        _currentSessionId.value = sessionId
        toggleHistoryDialog(false)
    }

    fun startNewSession() {
        viewModelScope.launch {
            val newId = repository.startNewSession()
            _currentSessionId.value = newId
            toggleHistoryDialog(false)
        }
    }

    fun deleteSession(sessionId: Long) {
        viewModelScope.launch {
            if (_currentSessionId.value == sessionId) {
                val sessionsAfterDeletion = repository.getAllSessions().first().filter { it.id != sessionId }
                if (sessionsAfterDeletion.isNotEmpty()) {
                    loadSession(sessionsAfterDeletion.first().id)
                } else {
                    startNewSession()
                }
            }
            repository.deleteSession(sessionId)
        }
    }


    // --- Lifecycle and Factory ---

    override fun onCleared() {
        super.onCleared()
        speechRecognizer.destroy()
        textToSpeech.shutdown()
    }

    class TranslatorViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(TranslatorViewModel::class.java)) {
                @Suppress("UNCHECKED_CAST")
                return TranslatorViewModel(application) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}